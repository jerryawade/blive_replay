# OBS Protocol Handler PowerShell Script

# Get input parameter
param(
    [Parameter(Mandatory=$true)]
    [string]$InputUrl
)

# Function: URL decode
function UrlDecode {
    param([string]$UrlEncodedString)
    
    Add-Type -AssemblyName System.Web
    return [System.Web.HttpUtility]::UrlDecode($UrlEncodedString)
}

# Function: Parse query string into hashtable
function ParseQueryString {
    param([string]$QueryString)
    
    $parameters = @{}
    
    if ([string]::IsNullOrEmpty($QueryString)) {
        return $parameters
    }
    
    $pairs = $QueryString.Split('&')
    foreach ($pair in $pairs) {
        $keyValue = $pair.Split('=')
        if ($keyValue.Length -eq 2) {
            $key = $keyValue[0]
            $value = UrlDecode $keyValue[1]
            $parameters[$key] = $value
        }
    }
    
    return $parameters
}

# Function: Process URL
function ProcessUrl {
    param([string]$Url)
    
    Write-Host "Input URL: $Url"
    
    # Default OBS arguments
    $obsArgs = ""
    
    # Check if it starts with obs:// and remove the prefix
    if ($Url -match "obs://(.+)") {
        $Url = $matches[1]
        Write-Host "Removed prefix: $Url"
    } else {
        Write-Host "URL format not recognized"
        return ""
    }
    
    # Parse command and query string
    $command = ""
    $queryString = ""
    
    if ($Url.Contains("?")) {
        $parts = $Url.Split('?', 2)
        $command = $parts[0]
        $queryString = $parts[1]
    } else {
        $command = $Url
    }
    
    Write-Host "Command: $command"
    Write-Host "Query string: $queryString"
    
    # Parse parameters
    $params = ParseQueryString $queryString
    
    # Check if the command is a URL (contains ":" which would indicate a protocol like http:// or rtmp://)
    if ($command -match ":") {
        # This is likely a URL - handle it directly
        $fullUrl = $command
        if (-not [string]::IsNullOrEmpty($queryString)) {
            $fullUrl += "?$queryString"
        }
        # URL decode the full URL in case it was encoded
        $decodedUrl = UrlDecode $fullUrl
        Write-Host "Detected URL: $decodedUrl"
        $obsArgs = "--url `"$decodedUrl`""
        return $obsArgs
    }
    
    # Determine OBS arguments based on command
    switch ($command) {
        "scene" {
            if ($params.ContainsKey("name")) {
                $obsArgs = "--scene `"$($params['name'])`""
            }
        }
        "profile" {
            if ($params.ContainsKey("name")) {
                $obsArgs = "--profile `"$($params['name'])`""
            }
        }
        "collection" {
            if ($params.ContainsKey("name")) {
                $obsArgs = "--collection `"$($params['name'])`""
            }
        }
        "start" {
            $startArgs = @()
            if ($params.ContainsKey("profile")) {
                $startArgs += "--profile `"$($params['profile'])`""
            }
            if ($params.ContainsKey("collection")) {
                $startArgs += "--collection `"$($params['collection'])`""
            }
            if ($params.ContainsKey("scene")) {
                $startArgs += "--scene `"$($params['scene'])`""
            }
            $obsArgs = $startArgs -join " "
        }
        "record" {
            $obsArgs = "--startrecording"
        }
        "stream" {
            $obsArgs = "--startstreaming"
        }
        "URL" {
            # Handle direct URL passing
            if ($params.ContainsKey("value")) {
                $decodedUrl = UrlDecode $params['value']
                Write-Host "URL value: $decodedUrl"
                $obsArgs = "--url `"$decodedUrl`""
            }
        }
        default {
            Write-Host "Unknown command: $command"
        }
    }
    
    return $obsArgs
}

# Main program
try {
    # Get script directory
    $scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
    $obsPath = Join-Path $scriptPath "obs64.exe"
    
    # Check if OBS exists
    if (-not (Test-Path $obsPath)) {
        Write-Host "Error: obs64.exe not found"
        Write-Host "Current directory: $scriptPath"
        Write-Host "Please make sure this script is in the OBS Studio installation directory."
        exit 1
    }
    
    # Process URL
    $obsArgs = ProcessUrl $InputUrl
    Write-Host "OBS arguments: $obsArgs"
    
    # Start OBS with the appropriate arguments
    if ($obsArgs -ne "") {
        Write-Host "Starting OBS..."
        Write-Host "Command line: '$obsPath' $obsArgs"
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = $obsPath
        $startInfo.Arguments = $obsArgs
        $startInfo.CreateNoWindow = $false
        $startInfo.UseShellExecute = $true
        $process = [System.Diagnostics.Process]::Start($startInfo)
    } else {
        Write-Host "No valid OBS arguments generated, starting OBS without arguments"
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = $obsPath
        $startInfo.CreateNoWindow = $false
        $startInfo.UseShellExecute = $true
        $process = [System.Diagnostics.Process]::Start($startInfo)
    }
    
    # Write logs to temp file for debugging
    $logFile = "$env:TEMP\obs-protocol.log"
    "$(Get-Date) - Input URL: $InputUrl" | Out-File -Append $logFile
    "$(Get-Date) - OBS arguments: $obsArgs" | Out-File -Append $logFile
} catch {
    $errorMessage = "Error occurred: $_"
    $errorMessage | Out-File -Append "$env:TEMP\obs-protocol-error.log"
    exit 1
}