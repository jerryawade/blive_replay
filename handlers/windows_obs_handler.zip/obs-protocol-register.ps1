# OBS Protocol Handler Registration Script
# This script requires administrator privileges

# Check for administrator privileges
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Error: This script requires administrator privileges."
    Write-Host "Please right-click the script and select 'Run as Administrator'."
    Read-Host "Press Enter to continue..."
    exit 1
}

try {
    # Get script directory
    $scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
    $obsPath = Join-Path $scriptPath "obs64.exe"
    $handlerPath = Join-Path $scriptPath "obs-protocol.ps1"
    
    # Check if required files exist
    if (-not (Test-Path $obsPath)) {
        Write-Host "Error: obs64.exe not found"
        Write-Host "Current directory: $scriptPath"
        Write-Host "Please make sure this script is in the OBS Studio installation directory."
        Read-Host "Press Enter to continue..."
        exit 1
    }
    
    if (-not (Test-Path $handlerPath)) {
        Write-Host "Error: obs-protocol.ps1 not found"
        Write-Host "Current directory: $scriptPath"
        Write-Host "Please make sure obs-protocol.ps1 is in the same directory."
        Read-Host "Press Enter to continue..."
        exit 1
    }
    
    Write-Host "Registering obs:// protocol handler..."
    
    # Register protocol
    $registryPath = "HKLM:\SOFTWARE\Classes\obs"
    
    # Create main key
    New-Item -Path $registryPath -Force | Out-Null
    Set-ItemProperty -Path $registryPath -Name "(Default)" -Value "URL:obs Protocol"
    Set-ItemProperty -Path $registryPath -Name "URL Protocol" -Value ""
    
    # Create DefaultIcon
    New-Item -Path "$registryPath\DefaultIcon" -Force | Out-Null
    Set-ItemProperty -Path "$registryPath\DefaultIcon" -Name "(Default)" -Value "`"$obsPath`",0"
    
    # Create shell\open\command
    New-Item -Path "$registryPath\shell\open\command" -Force | Out-Null
    $commandValue = "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -NonInteractive -NoProfile -File `"$handlerPath`" `"%1`""
    Set-ItemProperty -Path "$registryPath\shell\open\command" -Name "(Default)" -Value $commandValue
    
    Write-Host "Registration complete!"
    Write-Host "You can now use the following URL formats:"
    Write-Host "  obs://scene?name=SceneName"
    Write-Host "  obs://profile?name=ProfileName"
    Write-Host "  obs://collection?name=CollectionName"
    Write-Host "  obs://start?profile=ProfileName&collection=CollectionName&scene=SceneName"
    Write-Host "  obs://record"
    Write-Host "  obs://stream"
    Write-Host "  obs://URL - to directly pass a URL to OBS"
    
} catch {
    Write-Host "Error occurred: $_"
} finally {
    Read-Host "Press Enter to continue..."
}