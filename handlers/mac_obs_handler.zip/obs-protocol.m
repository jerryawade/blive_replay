#import <Cocoa/Cocoa.h>

// Based on https://www.cocoawithlove.com/2010/09/minimalist-cocoa-programming.html

@interface AppDelegate : NSObject <NSApplicationDelegate>
@end

@implementation AppDelegate

- (void)logError:(NSString *)message {
    [self logMessage:@"ERROR: %@", message];
    [NSApp terminate:nil];
}

- (void)logInfo:(NSString *)message {
    [self logMessage:@"INFO: %@", message];
}

- (BOOL)isOBSInstalled {
    return [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/OBS.app"];
}

- (NSString *)decodeURL:(NSString *)url {
    return [[url 
        stringByReplacingOccurrencesOfString:@"+" withString:@" "]
        stringByRemovingPercentEncoding];
}

- (void)logMessage:(NSString *)format, ... {
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    
    fprintf(stderr, "[OBS-Protocol] %s\n", [message UTF8String]);
}

- (NSString *)repairBrokenUrl:(NSString *)url {
    [self logMessage:@"Original URL: %@", url];
    
    // Fix Chrome 130+ format for common streaming protocols
    if ([url hasPrefix:@"rtmp//"]) {
        url = [url stringByReplacingCharactersInRange:NSMakeRange(0, 7) withString:@"rtmp://"];
        [self logMessage:@"Fixed RTMP URL: %@", url];
    } else if ([url hasPrefix:@"rtsp//"]) {
        url = [url stringByReplacingCharactersInRange:NSMakeRange(0, 7) withString:@"rtsp://"];
        [self logMessage:@"Fixed RTSP URL: %@", url];
    } else if ([url hasPrefix:@"srt//"]) {
        url = [url stringByReplacingCharactersInRange:NSMakeRange(0, 6) withString:@"srt://"];
        [self logMessage:@"Fixed SRT URL: %@", url];
    }
    
    return url;
}

- (void)handleAppleEvent:(NSAppleEventDescriptor *)event withReplyEvent: (NSAppleEventDescriptor *)replyEvent {
    [self logMessage:@"Received URL request"];
    
    // Check if OBS is installed
    if (![self isOBSInstalled]) {
        [self logError:@"OBS is not installed in /Applications"];
        return;
    }
    
    // Get input data
    NSString *input = [[event paramDescriptorForKeyword:keyDirectObject] stringValue];
    NSString *url;
    
    if ([input hasPrefix:@"obs://stream?"]) {
        // Handle stream format: obs://stream?url=rtmp://...
        NSString *query = [input substringFromIndex:12];  
        [self logMessage:@"Query part: %@", query];
        
        // Check for url= parameter
        if ([query hasPrefix:@"url="]) {
            url = [query substringFromIndex:4];
            // URL decode
            url = [self decodeURL:url];
            [self logMessage:@"Found URL: %@", url];
        } else {
            [self logError:[NSString stringWithFormat:@"Invalid stream format. URL parameter is missing. Query: %@", query]];
            return;
        }
    } else if ([input hasPrefix:@"obs://"]) {
        url = [input substringFromIndex:6];
    } else if ([input hasPrefix:@"obs:"]) {
        url = [input substringFromIndex:4];
    } else {
        [self logError:@"Invalid URL format. Must start with 'obs://' or 'obs://stream?url='."];
        return;
    }
    
    // First repair URL if needed
    url = [self repairBrokenUrl:url];
    
    // Then check protocol - OBS primarily supports these streaming protocols
    if (![url hasPrefix:@"rtmp://"] && ![url hasPrefix:@"rtsp://"] && 
        ![url hasPrefix:@"srt://"] && ![url hasPrefix:@"udp://"]) {
        [self logError:@"Only RTMP, RTSP, SRT, and UDP protocols are supported for streaming."];
        return;
    }

    // Launch OBS with the stream URL
    // Note: OBS doesn't have direct URL handling like VLC, so we'll use command line parameters
    // OBS can be launched with --startstreaming to automatically start streaming
    NSWorkspace *ws = [NSWorkspace sharedWorkspace];
    NSURL *app = [NSURL fileURLWithPath:@"/Applications/OBS.app"];
    
    // Create a temporary settings file with the stream URL
    NSString *tempDir = NSTemporaryDirectory();
    NSString *tempFile = [tempDir stringByAppendingPathComponent:@"obs_stream_url.txt"];
    NSError *fileError;
    [url writeToFile:tempFile atomically:YES encoding:NSUTF8StringEncoding error:&fileError];
    
    if (fileError) {
        [self logError:[NSString stringWithFormat:@"Failed to create temporary settings: %@", [fileError localizedDescription]]];
        return;
    }
    
    // Launch OBS with parameters
    NSArray *arguments = [NSArray arrayWithObjects: @"--startstreaming", @"--streamurl", url, nil];
    NSMutableDictionary *config = [[NSMutableDictionary alloc] init];
    [config setObject:arguments forKey:NSWorkspaceLaunchConfigurationArguments];
    
    NSError *error = nil;
    if (![ws launchApplicationAtURL:app options:NSWorkspaceLaunchNewInstance configuration:config error:&error]) {
        [self logError:[NSString stringWithFormat:@"Failed to launch OBS: %@", [error localizedDescription]]];
        return;
    }
    
    // Log info about the launched stream
    [self logInfo:[NSString stringWithFormat:@"OBS has been launched with the stream URL: %@", url]];
    
    [NSApp terminate:nil];
}

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    // Close this program if it wasn't launched using a link (i.e. launched normally)
    [NSApp terminate:nil];
}

@end

int main() {
    // Make sure the shared application is created
    [NSApplication sharedApplication];

    AppDelegate *appDelegate = [AppDelegate new];
    NSAppleEventManager *sharedAppleEventManager = [NSAppleEventManager new];
    [sharedAppleEventManager setEventHandler:appDelegate
                               andSelector:@selector(handleAppleEvent:withReplyEvent:)
                             forEventClass:kInternetEventClass
                                andEventID:kAEGetURL];

    [NSApp setDelegate:appDelegate];
    [NSApp run];
    return 0;
}