# Close all instances of Google Chrome
Get-Process -Name "chrome" -ErrorAction SilentlyContinue | Stop-Process -Force

# Close all instances of VLC Media Player
Get-Process -Name "vlc" -ErrorAction SilentlyContinue | Stop-Process -Force

Write-Host "Google Chrome and VLC instances have been closed."