# Function to check if the script is running as administrator
function Test-Admin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# If not running as administrator, restart with elevated privileges
if (-not (Test-Admin)) {
    Write-Host "Script is not running as administrator. Restarting with elevated privileges..."
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Define the task name and description
$taskName = "Close Chrome & VLC"
$taskDescription = "Closes all instances of Chrome and VLC daily at 1:00 AM."

# Define the path to the PowerShell script
$scriptPath = "C:\Scripts\CloseApps.ps1"

# Define the action (what the task will run)
$action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-ExecutionPolicy Bypass -File `"$scriptPath`""

# Define the trigger (daily at 1:00 AM)
$trigger = New-ScheduledTaskTrigger `
    -Daily `
    -At "1:00 AM"

# Define the task settings
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable `
    -WakeToRun

# Define the principal (run with highest privileges, whether logged in or not)
$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

# Create the scheduled task
Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description $taskDescription

# Output success message
Write-Host "Scheduled task '$taskName' created successfully. It will run daily at 1:00 AM."